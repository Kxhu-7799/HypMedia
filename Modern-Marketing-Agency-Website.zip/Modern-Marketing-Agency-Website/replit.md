# HypMedia marketing agency site

HypMedia is a motion-led, responsive marketing site for an independent creative agency.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/agency-site/src/App.tsx` — the single-page content model, sections, and interactions.
- `artifacts/agency-site/src/index.css` — the HypMedia visual system, responsive rules, and motion.
- `artifacts/agency-site/index.html` — SEO metadata, structured data, and analytics placeholders.
- `artifacts/agency-site/public/` — favicon, robots.txt, and sitemap.xml placeholders.

## Architecture decisions

- The first release is frontend-only so the marketing experience can ship before a form provider is selected.
- HypMedia is the working brand name; contact details, production domain, imagery, and tracking IDs are intentionally marked for handoff.
- CSS keyframes, IntersectionObserver, and transform/opacity transitions provide motion without a 3D or WebGL runtime.
- The contact form currently demonstrates the client-side success state and is ready to connect to the chosen lead endpoint.

## Product

The site presents HypMedia's positioning, services, work, process, testimonials, FAQs, and consultation CTA. It includes theme switching, a responsive mobile menu, work filters, testimonial controls, FAQ accordion, reduced-motion support, sticky mobile CTA, and a WhatsApp affordance.

## User preferences

- Follow the supplied brief: bold premium creative-agency presentation, polished 2D motion, dark-first palette with light-mode option, and no WebGL or 3D.

## Gotchas

- Replace all `replaceable-agency.example` contact values, WhatsApp number, production domain, OG image, and analytics IDs before launch.
- The form does not send leads until a provider such as Formspree, EmailJS, Supabase, or Google Sheets is connected.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
