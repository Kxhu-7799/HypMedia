import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  CircleCheck,
  Clock3,
  Mail,
  Menu,
  MessageCircle,
  Moon,
  Plus,
  Send,
  Sparkles,
  Sun,
  X,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const services = [
  { number: '01', title: 'Brand & positioning', copy: 'Find the sharpest version of what you do — then make it impossible to forget.' },
  { number: '02', title: 'Content systems', copy: 'Ideas with a point of view, made to earn attention and compound over time.' },
  { number: '03', title: 'Performance creative', copy: 'Creative built for the scroll, tested against reality, tuned for action.' },
  { number: '04', title: 'Social & community', copy: 'Turn passive audiences into people who reply, share, and come back.' },
];

const work = [
  { type: 'Brand', client: 'Morrow / D2C skincare', title: 'Soft power.', copy: 'A launch world for skin that does more.', className: 'tall' },
  { type: 'Content', client: 'Northstar / SaaS', title: 'Make complex feel clear.', copy: 'A content engine for a category creator.' },
  { type: 'Performance', client: 'Vela / Retail', title: 'Less noise. More want.', copy: 'Creative that gave a new ritual momentum.' },
];

const testimonials = [
  { quote: 'HypMedia gave us the language to become the brand we knew we could be. The work is beautiful, but the clarity is what changed the business.', name: 'Nadia Okafor', role: 'Founder, Morrow Skin', initials: 'NO', color: 'linear-gradient(135deg,#8e51ff,#ec6fac)' },
  { quote: 'They move like a small team and think like a very senior one. We went from explaining the product to people asking for it by name.', name: 'Theo Martin', role: 'Co-founder, Northstar', initials: 'TM', color: 'linear-gradient(135deg,#1f827e,#b4dbc5)' },
  { quote: 'The rare agency that can protect the big idea and still care about the metric. Our creative got sharper at every sprint.', name: 'Priya Shah', role: 'Brand lead, Vela', initials: 'PS', color: 'linear-gradient(135deg,#bb5a31,#efc18d)' },
];

const faqs = [
  { question: 'What kind of teams do you work best with?', answer: 'Founders and lean marketing teams who already know the work matters. We work with startups, D2C brands, local businesses, and ambitious SMEs who want a sharp outside perspective without a slow agency machine.' },
  { question: 'Can you work with our existing brand?', answer: 'Absolutely. We can pressure-test what is already there, tighten the story, and build a content system around it. A full identity is never a prerequisite for making the next right move.' },
  { question: 'How does a typical engagement start?', answer: 'Every engagement starts with a short working session. We map the business tension, the audience tension, and the opportunity between them. Then we return with a focused scope, a clear first sprint, and a realistic timeline.' },
  { question: 'Do you offer ongoing support after a launch?', answer: 'Yes. Most of our best work happens after launch, when we can read the signals and make the system smarter. Retainers are built around a monthly creative rhythm, not a pile of unused deliverables.' },
];

function Counter({ value, suffix = '', prefix = '' }: { value: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) {
      setCount(value);
      return;
    }
    let frame = 0;
    const started = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - started) / 1100, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Number((value * eased).toFixed(value % 1 ? 1 : 0)));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);

  return <>{prefix}{count}{suffix}</>;
}

function ThemeToggle({ theme, onToggle }: { theme: 'dark' | 'light'; onToggle: () => void }) {
  return (
    <button className="theme-toggle" type="button" onClick={onToggle} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`} data-testid="button-theme-toggle">
      {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
    </button>
  );
}

function Header({ theme, onToggle, menuOpen, setMenuOpen }: { theme: 'dark' | 'light'; onToggle: () => void; menuOpen: boolean; setMenuOpen: (open: boolean) => void }) {
  const navItems = [
    ['Work', '#work'],
    ['Services', '#services'],
    ['Process', '#process'],
    ['About', '#about'],
  ];
  return (
    <>
      <header className="site-header">
        <div className="container-wide header-inner">
          <a className="brand" href="#top" data-testid="link-brand-home" onClick={() => setMenuOpen(false)}>
            <span className="brand-mark" aria-hidden="true" />
            HypMedia<span className="gradient-text">.</span>
          </a>
          <nav className="desktop-nav" aria-label="Primary navigation">
            {navItems.map(([label, href]) => <a key={href} href={href} data-testid={`link-nav-${label.toLowerCase()}`}>{label}</a>)}
          </nav>
          <div className="header-actions">
            <ThemeToggle theme={theme} onToggle={onToggle} />
            <a className="header-cta gradient-fill" href="#contact" data-testid="link-header-start">Start a conversation <ArrowUpRight size={13} /></a>
            <button className="menu-toggle" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} data-testid="button-mobile-menu">
              {menuOpen ? <X size={17} /> : <Menu size={17} />}
            </button>
          </div>
        </div>
      </header>
      {menuOpen && (
        <div className="mobile-menu" role="dialog" aria-label="Mobile navigation">
          <nav>
            {navItems.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)} data-testid={`link-mobile-${label.toLowerCase()}`}>{label}</a>)}
          </nav>
          <a className="button-primary gradient-fill" href="#contact" onClick={() => setMenuOpen(false)} data-testid="link-mobile-contact">Tell us the good stuff <ArrowUpRight size={14} /></a>
        </div>
      )}
    </>
  );
}

function Hero() {
  return (
    <section className="hero" id="top">
      <div className="container-wide hero-grid">
        <div className="hero-copy">
          <span className="eyebrow">Independent creative partner</span>
          <h1>
            <span className="line"><span>Make noise</span></span>
            <span className="line"><span className="gradient-text">worth hearing.</span></span>
          </h1>
          <p>We turn good businesses into brands people talk about — through sharp strategy, magnetic content, and creative that knows where it is going.</p>
          <div className="hero-actions">
            <a className="button-primary gradient-fill" href="#contact" data-testid="link-hero-contact">Start a conversation <ArrowUpRight size={15} /></a>
            <a className="button-ghost" href="#work" data-testid="link-hero-work">See selected work <ArrowDownRight size={15} /></a>
          </div>
          <div className="hero-note">
            <div className="note-avatars" aria-hidden="true"><span>NO</span><span>TM</span><span>PS</span></div>
            <span>Trusted by teams building what is next.</span>
          </div>
        </div>
        <div className="hero-visual" aria-label="Placeholder campaign performance visual">
          <div className="hero-orbit" aria-hidden="true" />
          <div className="hero-panel glass">
            <div className="panel-top">
              <div><div className="panel-kicker">Signal report / 04</div><h3>Attention, earned.</h3></div>
              <div className="panel-spark gradient-fill"><Sparkles size={18} /></div>
            </div>
            <div className="chart" aria-label="Illustrative rising bar chart">
              {[1, 2, 3, 4, 5, 6, 7].map((bar) => <span className="chart-bar" key={bar} />)}
            </div>
            <div className="panel-bottom">
              <div><strong>+47.2%</strong><small>meaningful reach, month on month</small></div>
              <span className="trend">↑ 18.6%</span>
            </div>
          </div>
          <div className="floating-tag glass"><span>People are listening</span><strong>3.8×</strong></div>
          <div className="floating-tag glass two"><span>Visual placeholder</span><strong>Replace with campaign art</strong></div>
        </div>
      </div>
      <div className="hero-scroll" aria-hidden="true"><span>Scroll to explore</span><span className="scroll-line" /></div>
    </section>
  );
}

function Marquee() {
  const items = ['Brand with a pulse', 'Content with a point of view', 'Creative that compounds', 'Small team, big signal'];
  return <div className="marquee-wrap" aria-label="HypMedia capabilities"><div className="marquee">{[...items, ...items].map((item, index) => <span key={`${item}-${index}`}>{item} <b aria-hidden="true">+</b></span>)}</div></div>;
}

function About() {
  return (
    <section className="section" id="about">
      <div className="container-wide intro-grid">
        <div className="reveal"><span className="eyebrow">The HypMedia point of view</span></div>
        <div className="reveal">
          <p className="manifesto">The internet is loud. <em>Being louder is easy.</em> We help ambitious teams become the thing people notice, remember, and bring up in a group chat.</p>
          <div className="manifesto-underline gradient-fill" />
        </div>
      </div>
      <div className="container-wide stats-grid reveal" style={{ marginTop: 92 }}>
        <div className="stat"><strong><Counter value={18} /></strong><small>markets reached through one clear story</small></div>
        <div className="stat"><strong><Counter value={47.2} suffix="%" /></strong><small>average lift in meaningful reach</small></div>
        <div className="stat"><strong><Counter value={4.6} suffix="×" /></strong><small>more likely to be remembered</small></div>
        <div className="stat"><strong><Counter value={12} suffix=" wk" /></strong><small>from first spark to live system</small></div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section className="section" id="services">
      <div className="container-wide service-layout">
        <div className="section-heading reveal"><span className="eyebrow">What we make</span><h2>Clarity first.<br /><span className="gradient-text">Then magic.</span></h2><p>We keep the team tight, the thinking close, and the output built for the real world — not a pitch deck.</p></div>
        <div className="service-list reveal">
          {services.map((service) => <div className="service-row" key={service.number}><span className="service-number">{service.number}</span><div><h3>{service.title}</h3><p>{service.copy}</p></div><ArrowRight /></div>)}
        </div>
      </div>
    </section>
  );
}

function Work() {
  const [filter, setFilter] = useState('All');
  const filters = ['All', 'Brand', 'Content', 'Performance'];
  const visible = filter === 'All' ? work : work.filter((item) => item.type === filter);
  return (
    <section className="section" id="work">
      <div className="container-wide">
        <div className="work-header reveal">
          <div className="section-heading"><span className="eyebrow">Selected signals</span><h2>Work that<br /><span className="gradient-text">travels.</span></h2></div>
          <div className="filters" role="group" aria-label="Filter work">
            {filters.map((item) => <button className={`filter-button ${filter === item ? 'active' : ''}`} type="button" key={item} onClick={() => setFilter(item)} aria-pressed={filter === item} data-testid={`button-filter-${item.toLowerCase()}`}>{item}</button>)}
          </div>
        </div>
        <div className="work-grid reveal">
          {visible.map((item) => <article className={`work-card glass ${item.className ?? ''}`} key={item.client}><div className="work-card-bg" /><div className="work-meta"><span>{item.client}</span><span className="work-chip">{item.type}</span></div><div className="work-title"><h3>{item.title}</h3><p>{item.copy}</p></div></article>)}
        </div>
      </div>
    </section>
  );
}

function Process() {
  const steps = [
    ['01', 'Get close to the tension', 'A focused sprint to find the sharp truth between what you sell and what people want.'],
    ['02', 'Build the signal', 'A flexible creative system with enough spine to be recognizable and enough range to stay alive.'],
    ['03', 'Put it in the wild', 'Launch, listen, and learn. We stay close to the work until it earns its place in the conversation.'],
  ];
  return (
    <section className="section process" id="process">
      <div className="container-wide process-grid">
        <div className="reveal"><span className="eyebrow">How we work</span><div className="process-steps">{steps.map(([no, title, copy]) => <div className="process-step" key={no}><span className="step-no">{no}</span><div><h3>{title}</h3><p>{copy}</p></div></div>)}</div></div>
        <div className="process-art glass reveal" aria-label="Placeholder process illustration"><span className="eyebrow">The working model</span><div className="process-circle"><span className="process-orb" /></div><div className="process-caption"><span>Visual placeholder</span><span>Replace with process art</span></div></div>
      </div>
    </section>
  );
}

function Testimonials() {
  const [active, setActive] = useState(0);
  const item = testimonials[active];
  const move = (direction: number) => setActive((current) => (current + direction + testimonials.length) % testimonials.length);
  return (
    <section className="section quote-section">
      <div className="container-wide quote-layout">
        <div className="reveal"><span className="eyebrow">Good words, kept</span><h2 className="section-heading" style={{ fontFamily: "'Space Grotesk'", fontSize: 'clamp(38px, 5vw, 70px)', letterSpacing: '-.07em', lineHeight: '.98', margin: '19px 0 0' }}>The kind of partner you <span className="gradient-text">keep.</span></h2><div className="quote-controls"><button className="round-arrow" type="button" onClick={() => move(-1)} aria-label="Previous testimonial" data-testid="button-testimonial-previous"><ChevronLeft size={17} /></button><button className="round-arrow" type="button" onClick={() => move(1)} aria-label="Next testimonial" data-testid="button-testimonial-next"><ChevronRight size={17} /></button></div></div>
        <div className="quote-card glass reveal" key={item.name}><span className="quote-index">0{active + 1} / 0{testimonials.length}</span><div className="quote-mark">“</div><blockquote>{item.quote}</blockquote><div className="quote-author"><span className="author-initial" style={{ background: item.color }}>{item.initials}</span><span><strong>{item.name}</strong><small>{item.role}</small></span></div></div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="section" id="faq">
      <div className="container-wide faq-layout">
        <div className="section-heading reveal"><span className="eyebrow">Worth asking</span><h2>Questions,<br /><span className="gradient-text">answered.</span></h2><p>No agency fog. Just the useful version of the answer.</p></div>
        <div className="faq-list reveal">{faqs.map((item, index) => <div className={`faq-item ${open === index ? 'open' : ''}`} key={item.question}><button className="faq-trigger" type="button" onClick={() => setOpen(open === index ? null : index)} aria-expanded={open === index} data-testid={`button-faq-${index}`}><span>{item.question}</span>{open === index ? <X size={17} /> : <Plus size={17} />}</button><div className="faq-answer"><div><p>{item.answer}</p></div></div></div>)}</div>
      </div>
    </section>
  );
}

function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };
  return (
    <section className="section contact-section" id="contact">
      <div className="container-wide">
        <div className="contact-card glass reveal">
          <div className="contact-copy"><span className="eyebrow">Your move</span><h2>Bring us the <span className="gradient-text">good stuff.</span></h2><p>Tell us what you are building, where it feels stuck, and what would feel like a win. We will come back with a useful next step.</p><div className="contact-details"><a href="mailto:hello@replaceable-agency.example" data-testid="link-contact-email"><Mail size={13} /> hello@replaceable-agency.example</a><a href="tel:+10000000000" data-testid="link-contact-phone"><Clock3 size={13} /> Typically replies within 2 working days</a></div></div>
          <form className="contact-form" onSubmit={handleSubmit}>
            {submitted ? <div className="form-success"><CircleCheck size={18} /><span>Thanks — your note is in. This is a convincing client-side success state; connect the form endpoint before launch.</span></div> : <>
              <div className="field"><label htmlFor="name">Your name</label><input id="name" name="name" placeholder="A very real person" required data-testid="input-contact-name" /></div>
              <div className="field"><label htmlFor="email">Work email</label><input id="email" name="email" type="email" placeholder="you@company.com" required data-testid="input-contact-email" /></div>
              <div className="field"><label htmlFor="company">Company</label><input id="company" name="company" placeholder="The good idea" data-testid="input-contact-company" /></div>
              <div className="field"><label htmlFor="budget">Useful context</label><input id="budget" name="budget" placeholder="Launch, reposition, grow..." data-testid="input-contact-context" /></div>
              <div className="field full"><label htmlFor="message">The short version</label><textarea id="message" name="message" placeholder="What are you trying to make true?" required data-testid="input-contact-message" /></div>
              <button className="button-primary gradient-fill form-submit" type="submit" data-testid="button-contact-submit">Send the brief <Send size={14} /></button>
            </>}
          </form>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return <footer className="site-footer"><div className="container-wide footer-inner"><a className="brand" href="#top" data-testid="link-footer-home"><span className="brand-mark" aria-hidden="true" />HypMedia<span className="gradient-text">.</span></a><span className="footer-copy">© 2026 HypMedia. Built for conversations.</span><nav className="footer-links" aria-label="Footer"><a href="#faq" data-testid="link-footer-faq">FAQ</a><a href="#contact" data-testid="link-footer-contact">Contact</a><a href="https://www.instagram.com" target="_blank" rel="noreferrer" data-testid="link-footer-instagram">Instagram</a></nav></div></footer>;
}

function Home() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('hypmedia-theme');
      const next = stored === 'light' ? 'light' : 'dark';
      setTheme(next);
      document.documentElement.classList.toggle('dark', next === 'dark');
    } catch {
      document.documentElement.classList.add('dark');
    }
    const timer = window.setTimeout(() => setLoading(false), 520);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try { localStorage.setItem('hypmedia-theme', theme); } catch { /* replacement only: storage may be unavailable */ }
  }, [theme]);

  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>('.reveal'));
    if (!('IntersectionObserver' in window)) {
      nodes.forEach((node) => node.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.13 });
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="agency-site" id="top">
      {loading && <div className="entry-loader"><div className="loader-inner"><a className="brand" href="#top"><span className="brand-mark" aria-hidden="true" />HypMedia<span className="gradient-text">.</span></a><div className="loader-word">Ideas in, signal out</div></div></div>}
      <Header theme={theme} onToggle={() => setTheme(theme === 'dark' ? 'light' : 'dark')} menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Services />
        <Work />
        <Process />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <a className="whatsapp" href="https://wa.me/10000000000?text=Hi%20HypMedia%2C%20I%27d%20like%20to%20talk%20about%20a%20project." target="_blank" rel="noreferrer" aria-label="Start a WhatsApp conversation, replacement number" data-testid="link-whatsapp"><MessageCircle size={21} /></a>
      <div className="mobile-cta"><a className="button-primary gradient-fill" href="#contact" data-testid="link-mobile-sticky-cta">Start a conversation <ArrowUpRight size={14} /></a></div>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;